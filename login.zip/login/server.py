from flask import Flask, render_template,request, redirect, session, flash
from mysqlconnection import connectToMySQL   # import the function that will return an instance of a connection
import re
from flask_bcrypt import Bcrypt
app = Flask(__name__)
bcrypt=Bcrypt(app)
app.secret_key="this key is secret"
@app.route("/")
def index():
    return render_template("index.html")
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
@app.route("/register_user", methods=["POST"])
def add_user_to_db():
    is_valid = True
    if len(request.form['fname'])<1:
        is_valid = False
        flash("Please enter a first name.")
    if len(request.form['lname'])<1:
        is_valid = False
        flash("Please enter a last name.")
    if not EMAIL_REGEX.match(request.form['email']):
        is_valid = False
        flash("Please enter a valid e-mail.")
    if len(request.form['user_pass'])<2:
        is_valid = False
        flash("Please enter a valid password.")
    if request.form['user_pass']!=request.form['user_pass_conf']:
        is_valid = False
        flash("Please confirm the same password")
    # if request.form['user_pass']==request.form['user_pass_conf']:
    #     is_valid = False
    #     flash("Please confirm the same password.")
    if not is_valid:
        return redirect("/")
    pw_hash=bcrypt.generate_password_hash(request.form['user_pass'])
    mysql = connectToMySQL("users")
    query = "INSERT INTO users (first_name, last_name, email, password, created_at, updated_at) VALUES (%(fn)s, %(ln)s, %(em)s, %(pass)s, NOW(), NOW());"
    data= {
        "fn": request.form["fname"],
        "ln": request.form["lname"],
        "em": request.form['email'],
        "pass": pw_hash
    }
    print(pw_hash)
    new_user_id = mysql.query_db(query, data)
    return redirect("/success/"+str(new_user_id))
@app.route("/success/<id>")
def show_user(id):
    mysql = connectToMySQL("users")
    one_user=mysql.query_db("SELECT * FROM users where id = "+str(id)+";")
    return render_template("success.html", user=one_user)
@app.route("/login_user", methods=["POST"])
def show_login():
    mysql = connectToMySQL("users")
    query = "SELECT * FROM users WHERE users.email =%(em)s;"
    data= {
        "em": request.form['email'],
    }
    one_user= mysql.query_db(query, data)
    if bcrypt.check_password_hash(one_user[0]['password'], request.form['user_pass']):
        return redirect("/success/"+str(one_user[0]['id']))
    flash("Sorry, login information is incorrect")
    return render_template("/")
@app.route("/logout_user")
def logout_user():
    flash("You've been logged out.")
    return redirect("/")
if __name__ == "__main__":
    app.run(debug=True)